# LSTM Forex prediction
A long term short term memory recurrent neural network to predict forex time series 

The model can be trained on daily or minute data of any forex pair. The data can be downloaded 
from [here](http://www.histdata.com/download-free-forex-data/).

The lstm-rnn should learn to predict the next day or minute based on previous data.

The neural network is implemented on Theano. 

This code is under development.




